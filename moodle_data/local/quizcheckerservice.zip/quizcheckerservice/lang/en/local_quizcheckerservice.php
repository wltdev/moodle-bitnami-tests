<?php

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Quiz Checker';
$string['quizchecker:description'] = 'Retrieve quizzes from a course and check if the user has started them.';
$string['quizchecker:has_started'] = 'Has started';
$string['quizchecker:not_started'] = 'Not started';
