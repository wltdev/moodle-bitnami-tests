<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_quizcheckerservice';
$plugin->version = 2024062300;
$plugin->requires = 2019052000; // Moodle 3.7+
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0';
