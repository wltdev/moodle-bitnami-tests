<?php

$string['pluginname'] = 'Quiz JSON Service';
$string['get_attempt_data'] = 'Get Attempt Data in JSON format';
