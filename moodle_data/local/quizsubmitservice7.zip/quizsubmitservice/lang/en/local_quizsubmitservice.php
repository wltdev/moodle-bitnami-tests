<?php

// Definindo o idioma padrão para o plugin local_quizsubmit.
$string['pluginname'] = 'Quiz Submission';
$string['submit_quiz_attempt'] = 'Submit Quiz Attempt';
$string['quizsubmission'] = 'Quiz Submission';
$string['status'] = 'Submission Status';
$string['status_desc'] = 'Status of the quiz submission';
