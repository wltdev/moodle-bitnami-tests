<?php
// File: local/getuserinfoservice/lang/en/local_getuserinfoservice.php

$string['pluginname'] = 'User Information Service'; // Plugin name
$string['getuserinfo'] = 'Get User Information'; // Function description or label
$string['description'] = 'This plugin provides a service to get detailed user information.'; // Description of the plugin
