<?php
// File: local/getuserinfoservice/lang/pt/local_getuserinfoservice.php

$string['pluginname'] = 'Serviço de Informações do Usuário'; // Plugin name
$string['getuserinfo'] = 'Obter Informações do Usuário'; // Function description or label
$string['description'] = 'Este plugin fornece um serviço para obter informações detalhadas sobre usuários.'; // Description of the plugin
