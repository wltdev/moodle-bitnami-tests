<?php

// Definindo o idioma padrão para o plugin local_quizsubmit.
$string['pluginname'] = 'Submissão de Quiz';
$string['submit_quiz_attempt'] = 'Enviar Tentativa de Quiz';
$string['quizsubmission'] = 'Submissão de Quiz';
$string['status'] = 'Status da Submissão';
$string['status_desc'] = 'Status da submissão do quiz';
